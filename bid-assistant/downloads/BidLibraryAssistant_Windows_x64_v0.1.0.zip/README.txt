﻿投标资料助手（Windows 10/11 64位）
1. 双击 BidLibraryAssistant_Setup.exe 一键安装。
2. 在投标助手网页生成六位配对码。
3. 选择公司资料库并开始扫描。
4. 如需卸载，请在 Windows 设置的应用列表中选择‘投标资料助手’。
